<?php
use Phalcon\Mvc\Model;

class Province extends Model
{
    public $id;
    public $province;
}
?>